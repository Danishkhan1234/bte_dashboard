<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class ExpertExperience extends Model 
{

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'expert_experience';



}
